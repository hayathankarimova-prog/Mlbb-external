LOCAL_PATH := $(call my-dir)

# --- Curl Prebuilt ---
include $(CLEAR_VARS)
LOCAL_MODULE := libcurl
LOCAL_SRC_FILES := src/curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/src/curl/curl-android-$(TARGET_ARCH_ABI)/include
include $(PREBUILT_STATIC_LIBRARY)

# --- SSL Prebuilt ---
include $(CLEAR_VARS)
LOCAL_MODULE := libssl
LOCAL_SRC_FILES := src/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

# --- Crypto Prebuilt ---
include $(CLEAR_VARS)
LOCAL_MODULE := libcrypto
LOCAL_SRC_FILES := src/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
#[[使用opengl绘制，否则使用vulkan绘制]] (1=opengl)(0=vulkan)
OPENGL_DRAW = 1

LOCAL_MODULE := Starcool.sh

LOCAL_CFLAGS := -std=c++20 -fvisibility=hidden
LOCAL_CPPFLAGS := -std=c++20 -fvisibility=hidden

LOCAL_CFLAGS += -DVK_USE_PLATFORM_ANDROID_KHR
LOCAL_CPPFLAGS += -DVK_USE_PLATFORM_ANDROID_KHR


ifeq ($(OPENGL_DRAW), 1)
   LOCAL_CFLAGS += -DUSE_OPENGL
   LOCAL_CPPFLAGS += -DUSE_OPENGL
endif

LOCAL_CPPFLAGS += -w -s -Wno-error=format-security -fvisibility=hidden -Werror -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fpermissive -Wall -fexceptions
#引入头文件到全局#
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include/Android_vulkan
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include/ImGui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include/ImGui/backends
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include/Memory
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/app
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/config
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/features
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/ui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/utils
LOCAL_C_INCLUDES += $(LOCAL_PATH)/src/curl/curl-android-$(TARGET_ARCH_ABI)/include


LOCAL_SRC_FILES := \
    src/app/main.cpp \
    src/features/RoomInfo.cpp \
    src/Android_draw/draw.cpp \
    src/Android_touch/TouchHelperA.cpp \
    src/ImGui/imgui.cpp \
    src/ImGui/imgui_demo.cpp \
    src/ImGui/imgui_draw.cpp \
    src/ImGui/imgui_tables.cpp \
    src/ImGui/imgui_widgets.cpp \
    src/ImGui/stb_image.cpp \
    src/ImGui/backends/imgui_impl_android.cpp \
    src/utils/oxorany.cpp \
    src/Includes/GUI_Custom.cpp \
    src/Memory/Memory.cpp \
    src/Memory/MemoryTools.cpp \
    src/icon/HeroIcons.cpp \
    src/icon/Rank/RankIcons_loader.cpp \
    src/icon/Spell/SpellIcons_loader.cpp \
    src/icon/skill_mlbb/SkillIcons_loader.cpp \


# Terapkan OLLVM secara spesifik ke file Keamanan
# (main.cpp dikosongkan flagnya agar tidak crash)
src/features/RoomInfo.o: LOCAL_CFLAGS += $(LOCAL_CFLAGS_OBF)
src/utils/oxorany.o: LOCAL_CFLAGS += $(LOCAL_CFLAGS_OBF)


ifeq ($(OPENGL_DRAW), 1)
    LOCAL_SRC_FILES += src/ImGui/backends/imgui_impl_opengl3.cpp
else
    LOCAL_SRC_FILES += src/ImGui/backends/imgui_impl_vulkan.cpp 
    LOCAL_SRC_FILES += src/Android_vulkan/vulkan_wrapper.cpp 
    LOCAL_SRC_FILES += src/Android_vulkan/VulkanUtils.cpp
endif

LOCAL_STATIC_LIBRARIES := libcurl libssl libcrypto
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lz

# FLAG UNTUK MEMBUAT FILE TERLIHAT KOSONG/TANPA SIMBOL DI IDA
LOCAL_LDFLAGS += -Wl,--strip-all
LOCAL_LDFLAGS += -Wl,-gc-sections
LOCAL_LDFLAGS += -Wl,--exclude-libs,ALL

include $(BUILD_EXECUTABLE)
