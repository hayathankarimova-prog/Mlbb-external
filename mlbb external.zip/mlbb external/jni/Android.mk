LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

# [[[ Графикалык Өзөктү Тандоо ]]]
# 1 = OpenGL ES3 колдонуу (Эски)
# 0 = Vulkan API колдонуу (Эң ылдам жана сунушталган вариант)
OPENGL_DRAW = 0

LOCAL_MODULE := rsa

# Коддун аткарылуу ылдамдыгын максималдуу жогорулатуу флагдары (Optimization)
LOCAL_CFLAGS := -O3 -flto -std=c++17 -fvisibility=hidden
LOCAL_CPPFLAGS := -O3 -flto -std=c++17 -fvisibility=hidden -fexceptions -fpermissive -Wall

LOCAL_CFLAGS += -DVK_USE_PLATFORM_ANDROID_KHR
LOCAL_CPPFLAGS += -DVK_USE_PLATFORM_ANDROID_KHR

ifeq ($(OPENGL_DRAW), 1)
   LOCAL_CFLAGS += -DUSE_OPENGL
   LOCAL_CPPFLAGS += -DUSE_OPENGL
endif

LOCAL_CPPFLAGS += -w -s -Wno-error=format-security -Werror -Wno-error=c++11-narrowing

# Негизги башкы файлдардын папкалары (Headers)
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/include \
    $(LOCAL_PATH)/include/Android_vulkan \
    $(LOCAL_PATH)/include/ImGui \
    $(LOCAL_PATH)/include/ImGui/backends \
    $(LOCAL_PATH)/include/Memory

# Негизги С++ коддук файлдары
LOCAL_SRC_FILES := \
    src/main.cpp \
    src/Android_draw/draw.cpp \
    src/Android_touch/TouchHelperA.cpp \
    src/ImGui/imgui.cpp \
    src/ImGui/imgui_demo.cpp \
    src/ImGui/imgui_draw.cpp \
    src/ImGui/imgui_tables.cpp \
    src/ImGui/imgui_widgets.cpp \
    src/ImGui/stb_image.cpp \
    src/ImGui/backends/imgui_impl_android.cpp \
    src/oxorany.cpp \
    src/Memory/Memory.cpp \
    src/Memory/MemoryTools.cpp

# Тандалган графикалык бэкэндге жараша файлдарды автоматтык түрдө кошуу
ifeq ($(OPENGL_DRAW), 1)
    LOCAL_SRC_FILES += src/ImGui/backends/imgui_impl_opengl3.cpp
    LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -ldl
else
    LOCAL_SRC_FILES += \
        src/ImGui/backends/imgui_impl_vulkan.cpp \
        src/Android_vulkan/vulkan_wrapper.cpp \
        src/Android_vulkan/VulkanUtils.cpp
    # Vulkan линковкасы кошулду
    LOCAL_LDLIBS := -llog -landroid -lvulkan -ldl
endif

include $(BUILD_EXECUTABLE)
